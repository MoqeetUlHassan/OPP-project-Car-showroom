import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;

public class Runner {
    public static void main(String[] args){
        MainFrame m = new MainFrame();

        }
}
